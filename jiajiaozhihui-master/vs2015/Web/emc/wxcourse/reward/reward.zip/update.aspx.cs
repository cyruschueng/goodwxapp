using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SfSoft.Common;
using SfSoft.SfEmc;
namespace SfSoft.web.emc.wxcourse.reward
{
    public partial class update : SfSoft.SfEmc.EmcDetailPage
    {

        Model.WX_Course_Reward modelArts = new SfSoft.Model.WX_Course_Reward();
        BLL.WX_Course_Reward bllArts = new BLL.WX_Course_Reward();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string mode = Request.Params["mode"].ToString();
                string ID = Request.Params["ID"].ToString();

                hfMode.Value = mode;
                hfID.Value = ID;
                hfMID.Value = "emc.wxcourse.reward";

                //�޸�
                if (hfMode.Value == "update")
                {
                    modelArts = bllArts.GetModel(int.Parse(ID));
                    if (modelArts != null)
                    {
                        this.ShowInfo(modelArts);
                    }
                }
            }
        }
        //1.��ʼ��ģ��ID
        protected override void VtInitMID()
        {
            hfMID.Value = "emc.wxcourse.reward";
        }
        protected override void VtInitToolbars()
        {
            VtInitEditToolbars();
        }
        protected override void VtInitBaseToolsBars()
        {
            VtInitBaseDetailToolsBars();
        }
        private void ShowInfo(Model.WX_Course_Reward model)
        {
            txtStartNumber.Text = model.StartNumber.ToString();
            txtEndNumber.Text = model.EndNumber.ToString();
            txtRate.Text = (model.Rate * 100).ToString();
            if (model.Type != null) {
                ddlType.Items.FindByValue(model.Type.ToString()).Selected=true;
            }
        }
        protected override void VtSave()
        {
            string strErr = "";
            strErr = checkform();
            if (strErr != "")
            {
                MessageBox.Show(this, strErr);
                OperateSuccess = false;
                return;
            }
            Model.WX_Course_Reward model = new Model.WX_Course_Reward();
            //���浥��
            if (hfMode.Value == "add")
            {
                model = this.SetModelValue(model);
                
                int index = bllArts.Add(model);
                hfMode.Value = "update";
            }
            else
            {
                string ID = hfID.Value;
                model = bllArts.GetModel(int.Parse(ID));
                model = this.SetModelValue(model);                
                bllArts.Update(model);
            }
        }

        private Model.WX_Course_Reward SetModelValue(Model.WX_Course_Reward model)
        {
            model.EndNumber = int.Parse(txtEndNumber.Text.Trim());
            model.Rate = decimal.Parse(txtRate.Text)/100;
            model.StartNumber = int.Parse(txtStartNumber.Text);
            if(ddlType.SelectedItem!=null && ddlType.SelectedValue!=""){
                model.Type =int.Parse(ddlType.SelectedValue);
            }
            return model;
        }
        private string checkform()
        {
            string strErr = "";
            if (this.txtStartNumber.Text == "" || !SfSoft.Common.PageValidate.IsNumber1(txtStartNumber.Text))
            {
                strErr += "��ʼ���ݲ���Ϊ���������֣�\\n";
            }
            if (txtEndNumber.Text.Trim() == "" || !SfSoft.Common.PageValidate.IsNumber1(txtEndNumber.Text))
            {
                strErr += "�������ݲ���Ϊ���������֣�\\n";
            }
            if (txtRate.Text.Trim() == "" || !SfSoft.Common.PageValidate.IsDecimalSign(txtRate.Text) )
            {
                strErr += "���ʲ���Ϊ���������֣�\\n";
            }
            if (ddlType.SelectedItem==null || ddlType.SelectedValue=="") {
                strErr += "���Ͳ���Ϊ�գ�\\n";
            }
           
            return strErr;
        }
    }
}
