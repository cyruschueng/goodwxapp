﻿$(function () {
    var partin = new PartIn();
    $("#record").click(function () {
        $("#audioModal").modal("show");
    });
    $("#images").click(function () {
        $("#imgModal").modal("show");
    });
})
var PartIn = function () {
    var record = $("#record");

}