﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SfSoft.web.game.brainsexpert.Models
{
    public class LocationConfig
    {
        public string  Type { get; set; }
        public int Quantity { get; set; }
        public int Score { get; set; }
    }
}