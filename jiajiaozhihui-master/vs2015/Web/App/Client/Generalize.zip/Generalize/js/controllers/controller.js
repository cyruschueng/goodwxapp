﻿app.controller('createController', ['$scope', '$location', 'wxJsSdkService', 'createService', '$location', 'cacheService', function ($scope, $location, wxJsSdkService, createService, $location, cacheService) {
    $scope.showLoadding = false;
    $scope.valid_date = "";
    $scope.title = "";

    $scope.currentGrade='1';
    $scope.grade=[
        {name:'初级群', value:'1'},
        {name:'高级群', value:'2'},
    ];
    createService.init().then(function(res){
        $scope.currentClass = res.classList[0];
        $scope.classList=res.classList;
        $scope.title=res.groupName;
    });
    $scope.test=function(){
        //console.log($scope.currentClass);
        alert($scope.currentClass + '&&&' + $scope.currentGrade)
    }
    $scope.chooseImage = function () {
        if ($scope.valid_date == "") {
            alert("请输入有效日期");
            return;
        }
        if ($scope.title == "") {
            alert("请输入标题");
            return;
        }
        var user = cacheService.user;
        if (user.id == undefined || user.id == null) {
            $location.path("/login");
        }
        wxJsSdkService.chooseImage(function () {
            wxJsSdkService.uploadImage(function (data) {
                $scope.showLoadding = true;
                createService.uploadImg(data.serverId, $scope.valid_date, $scope.title,$scope.currentGrade,$scope.currentClass ).then(function (result) {
                    if (result == "ok") {
                        $scope.showLoadding = false;
                        $location.path("/tip").search({
                            title: "上传成功",
                            desc: "",
                            hash: "create",
                            img: ""
                        });
                    } else {
                        $location.path("/tip").search({
                            title: "上传失败",
                            desc: "",
                            hash: "create",
                            img: ""
                        });
                    }
                })
            })
        });
    };
} ]);
app.controller('tipController', ['$scope', '$location', function ($scope, $location) {
    var params = $location.search();
    $scope.params = {
        title: params.title,
        desc: params.desc,
        hash: params.hash,
        href: params.href,
        img: params.img
    };
}]);

app.controller('loginController', ['$scope', 'loginService', '$location', function ($scope, loginService, $location) {
    $scope.userInfo = {
        userName: "",
        password:""
    }
    $scope.submitted = false
    $scope.error = false;
    $scope.login = function () {
        if ($scope.loginForm.$valid) {
            loginService.login($scope.userInfo.userName, $scope.userInfo.password).then(function (result) {
                console.log(result);
                if (result == "") {
                    $scope.error = true;
                    console.log("空");
                } else {
                    
                    $location.path("/home");
                }
            });
        } else {
            $scope.submitted = true;
        }
    }
}]);
app.controller('homeController', ['$scope', 'homeService', '$location', '$rootScope', function ($scope, homeService, $location, $rootScope) {

    homeService.list().then(function (result) {
        console.log('listlist');
        console.log(result);
        $scope.list = result;
    });
    
    $scope.busy=false;
    $scope.using = function (groupId,catalogue) {
        $scope.busy=true;
        homeService.using(groupId,catalogue).then(function (result) {
            $scope.busy=false;
            $scope.list = result;
        });
    }
    $scope.detail = function (id) {
        $location.path("/detail").search({ id: id });
    };
    $scope.isValidDate = function (date) {
        var now = moment().format("YYYY-MM-DD");
        var end = moment(date).format("YYYY-MM-DD");
        var t1 = moment(now).isBefore(moment(end));
        var t2 = moment(now).isSame(moment(end));
        return t1 || t2;
    };
    $scope.groupName = homeService.getGroupName();
}]);

app.controller('detailController', ['$scope', 'homeService', '$location', function ($scope, homeService, $location) {
    var id = $location.search().id;
    homeService.detail(id).then(function (result) {
        $scope.info = result;
        console.log(result);
    });
    $scope.delete = function (id) {
        if (confirm("你确定要从列表中移除当前数据吗？")) {
            homeService.dele(id).then(function (result) {
                $location.path("/home");
            });
        }
    }
    $scope.isValidDate = function (date) {
        var now = moment().format("YYYY-MM-DD");
        var end = moment(date).format("YYYY-MM-DD");
        var t1 = moment(now).isBefore(moment(end));
        var t2 = moment(now).isSame(moment(end));
        return t1 || t2;
    };
}]);
app.controller('posterController', ['$scope', 'posterService', '$location', function ($scope, posterService, $location) {
    $scope.showLoadding = false;
    $scope.createPoster = function () {
        $scope.showLoadding = true;
        posterService.createPoster().then(function (result) {
            if (result == "ok") {
                $scope.showLoadding = false;
                $location.path("/tip").search({
                    title: "海报生成成功",
                    desc: "<p class='text-left text-muted'>请注意查看公众号消息<p>",
                    hash: "home",
                    img: ""
                });
            } else {
                $scope.showLoadding = false;
                $location.path("/tip").search({
                    title: "海报生成失败",
                    desc: "",
                    hash: "home",
                    img: ""
                });
            }
        })
    };
    $scope.createAdvancedPoster = function () {
        $scope.showLoadding = true;
        posterService.createAdvancedPoster().then(function (result) {
            if (result == "ok") {
                $scope.showLoadding = false;
                $location.path("/tip").search({
                    title: "海报生成成功",
                    desc: "<p class='text-left text-muted'>请注意查看公众号消息<p>",
                    hash: "home",
                    img: ""
                });
            } else {
                $scope.showLoadding = false;
                $location.path("/tip").search({
                    title: "海报生成失败",
                    desc: "",
                    hash: "home",
                    img: ""
                });
            }
        })
    }
}]);
