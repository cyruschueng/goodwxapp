﻿(function ($) {
    var config = $.getJssdkConfig({
        url: '../server/pay.ashx?type=sdk'
    });
    var payConfig = $.getJsPayConfig({
        url: '../server/pay.ashx?type=pay'
    }, function () {
        $("#loadingToast").hide();
    });
    wx.config({
        debug: true,
        appId: config.appId,
        timestamp: config.timestamp,
        nonceStr: config.nonceStr,
        signature: config.signature,
        jsApiList: ["onMenuShareTimeline", "onMenuShareAppMessage", "chooseWXPay"]
    });
    $(document).on("click", "#btnPay", function () {
        $.ajax({
            url: '../server/course.ashx?type=save',
            type: 'POST',
            dataType: 'JSON',
            data: {},
            success: function (data) {
                alert(data.code);
                if (data.code == 1) {
                    var data = {
                        timestamp: payConfig.timeStamp,
                        nonceStr: payConfig.nonceStr,
                        package: payConfig.package,
                        signType: payConfig.signType,
                        paySign: payConfig.paySign
                    };
                    alert(JSON.stringify(data));
                    wx.chooseWXPay(data, function (res) {

                    });
                }
            }
        })
    })
})(jQuery)


