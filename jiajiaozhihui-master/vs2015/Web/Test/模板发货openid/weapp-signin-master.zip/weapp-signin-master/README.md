# weapp-signin

##微信小程序 - 易打卡
	小程序开发框架的目标是通过尽可能简单、高效的方式让开发者可以在微信中开发具有原生 APP 体验的服务。
### WEB开发工具
	[下载地址](https://mp.weixin.qq.com/debug/wxadoc/dev/devtools/download.html?t=20161122)



