var alter= {
  showModalStatus: false
}
module.exports = {
  alter: alter
}