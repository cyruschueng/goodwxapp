var app = getApp()
Page({
  data: {
    innerHeight: 1,
    innerWidth: 1,
    indicatorDots: false,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    list: [],
    email:'',
    title:'',
    question:'',
    not:[],
    success:''
  },

  onLoad: function () {

  },
  bindEmail:function(e){
    this.setData({email:e.detail.value})
  },
  bindTitle:function(e){
    this.setData({ title: e.detail.value })
  },
  bindTera:function(e){
    console.log(e.detail.value)
    this.setData({ question: e.detail.value })
  },
  submit:function(){
    var that = this
    wx.request({
      url: 'https://www.medusachina.com/lyb/TmeMessage/addmsg',
      data:{
        remail:that.data.email,
        msgtitle:that.data.title,
        msgcontent: that.data.question
      },
      success:function(res){
        console.log(res)
        if (res.data.success == false) {
          wx.showToast({
            title: '发送失败',
            icon: 'loading',
            duration: 2000
          })
        } else {
          wx.showToast({
            title: '发送成功',
            icon: 'success',
            duration: 2000
          })
        }
      }
    })
    
  },
  onShow: function () {
    var that = this
    wx.getSystemInfo({
      success: function (res) {
        console.log(res)
        that.setData({
          innerHeight: res.screenHeight,
          innerWidth: res.windowWidth
        })
      },
    })
    wx.request({
      url: 'https://op.juhe.cn/onebox/exchange/query?key=5ff39134b98b47e032a66a190e603aae',
      success: function (res) {
        console.log(res)
        if (res.data.error_code != 10012) {
          that.setData({
            list: res.data.result.list
          })
        }
      }
    })
    wx.login({
      success: function (res) {
        console.log(res)
        if (res.code) {
          console.log(res)
          var code = res.code
          wx.getUserInfo({
            success: function (res) {
              console.log(res)
              var userInfo = res.userInfo
              var date = new Date()
              wx.request({
                url: 'https://www.medusachina.com/lyb/TWxUser/WXUserLoginAdd',
                data: {
                  openid: code,
                  nickname: userInfo.nickName,
                  avatarurl: 'avatar',
                  flag:0,
                  isdelete:0
                },
                method:'get',
                success: function (res) {
                  console.log(res)
                },
                fail: function (res) {

                }
              })
            },
            fail:function(res){

            }
          })
          
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    })
    wx.request({
      url: 'https://www.medusachina.com/lyb/TtoTopMsg/select',
      success:function (res) {
        console.log(res)
        that.setData({not:res.data.rows})
      }
    })
  },
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
    var that = this
    wx.getSystemInfo({
      success: function (res) {
        console.log(res)
        that.setData({
          innerHeight: res.screenHeight,
          innerWidth: res.windowWidth
        })
      },
    })
    wx.request({
      url: 'https://op.juhe.cn/onebox/exchange/query?key=5ff39134b98b47e032a66a190e603aae',
      success: function (res) {
        console.log(res)
        if (res.data.error_code != 10012) {
          that.setData({
            list: res.data.result.list
          })
        }
      }
    })
    wx.login({
      success: function (res) {
        console.log(res)
        if (res.code) {
          console.log(res)
          var code = res.code
          wx.getUserInfo({
            success: function (res) {
              console.log(res)
              var userInfo = res.userInfo
              var date = new Date()
              wx.request({
                url: 'https://www.medusachina.com/lyb/TWxUser/WXUserLoginAdd',
                data: {
                  openid: code,
                  nickname: userInfo.nickName,
                  avatarurl: 'avatar',
                  flag: 0,
                  isdelete: 0
                },
                method: 'get',
                success: function (res) {
                  console.log(res)
                },
                fail: function (res) {

                }
              })
            },
            fail: function (res) {

            }
          })

        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    })
    wx.request({
      url: 'https://www.medusachina.com/lyb/TtoTopMsg/select',
      success: function (res) {
        console.log(res)
        that.setData({ not: res.data.rows })
      }
    })
  }

})
