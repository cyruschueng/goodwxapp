<template>
  <div class="sunwo-container">
    <div class="carousel">
      <el-carousel trigger="click" autoplay="true" interval="5000">
        <div class="sunwo-nav">
          <div class="logo">
            <img class="logo-img" src="/static/img/logo.png" width="40px">
            <span class="logo-txt">SUNWO</span>
          </div>
          <ul class="nav-list">
            <li v-for="(item,itemIndex) in navList" v-bind:key="itemIndex">
              <a class="{active:item.active}">{{item.label}}</a>
            </li>
          </ul>
        </div>
        <el-carousel-item v-for="item in 4" :key="item">
          <h3>5123</h3>
        </el-carousel-item>
      </el-carousel>
    </div>
  </div>
</template>

<style>
@import url('/static/css/home.css');
</style>

<script>

export default {
  data() {
    return {
      carouselStyle: { height: window.innerHeight },
      navList: [
        { label: '首页', active: true },
        { label: '产品案例', active: false },
        { label: 'sunwo服务', active: false },
        { label: '关于我们', active: false }
      ]
    }
  },
  mounted: function() {
    window.addEventListener('scroll', this.scrollPage)
  },
  methods: {
    scrollPage: function() {

    }
  }
}
</script>

