module.exports = {
  NODE_ENV: '"production"'
}
